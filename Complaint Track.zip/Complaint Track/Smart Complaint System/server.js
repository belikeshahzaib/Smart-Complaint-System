// server.js
const express = require('express');
const session = require('express-session');
const path = require('path');
const { getDB } = require('./db/database');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'fast-nuces-complaint-system-2024-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

app.use((req, res, next) => {
  res.locals.session = req.session;
  res.locals.unreadCount = 0;
  if (req.session && req.session.userId) {
    try {
      const db = getDB();
      const row = db.prepare('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0').get(req.session.userId);
      res.locals.unreadCount = row ? row.cnt : 0;
    } catch(e) {}
  }
  next();
});

getDB(); 

const authRoutes = require('./routes/auth');
const studentRoutes = require('./routes/student');
const technicianRoutes = require('./routes/technician');
const adminRoutes = require('./routes/admin');

app.use('/', authRoutes);
app.use('/student', studentRoutes);
app.use('/technician', technicianRoutes);
app.use('/admin', adminRoutes);

app.get('/', (req, res) => {
  if (req.session && req.session.userId) {
    const role = req.session.role;
    if (role === 'admin') return res.redirect('/admin/dashboard');
    if (role === 'technician') return res.redirect('/technician/dashboard');
    return res.redirect('/student/dashboard');
  }
  res.render('home', { title: 'Smart Complaint System - FAST NUCES' });
});

app.get('/about', (req, res) => {
  res.render('about', { title: 'About Us' });
});

app.use((req, res) => {
  res.status(404).render('404', { title: 'Page Not Found' });
});

app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════╗');
  console.log('║   Smart Complaint & Service Management System        ║');
  console.log('║   FAST NUCES - Areeba Imran & Shahzaib Zaheer        ║');
  console.log('╠══════════════════════════════════════════════════════╣');
  console.log(`║   Server running at: http://localhost:${PORT}           ║`);
  console.log('║   Default Admin: admin@nuces.edu.pk / admin123       ║');
  console.log('╚══════════════════════════════════════════════════════╝');
  console.log('');
});

module.exports = app;
